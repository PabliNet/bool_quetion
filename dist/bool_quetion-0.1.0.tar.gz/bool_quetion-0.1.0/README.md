# bool_quetion
Módulo para preguntar por sí o por no
